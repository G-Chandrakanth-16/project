package SingletonPattern;
public class TestBrowser {

    public static void main(String[] args) {
        Browser browser1 = Browser.getInstance();
        Browser browser2 = Browser.getInstance();
        System.out.println(browser1 == browser2);
        }
}