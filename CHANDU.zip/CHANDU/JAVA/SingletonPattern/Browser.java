package SingletonPattern;
public class Browser{
    private static Browser browser = null;
    private Browser(){};
    public static Browser getInstance(){
        if(browser == null){
            browser = new Browser();
        }
        // if we use multithreading we can use this synchronized block to create only one instance
        // if(browser == null){
        //     synchronized(Browser.class){
        //         if(browser == null){
        //             browser = new Browser();
        //         }
        //     }
        // }
        return browser;
    }
    public void showInfo(){
        System.out.println("This is a browser");
    }
}